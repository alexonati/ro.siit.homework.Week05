package org.example;

public abstract class Manufacturer implements Phone {
   String name;
}
