package org.example;

public abstract class Apple extends Manufacturer {

   public String getName () {
      return name;
   }

   public void setName (String name) {
      this.name = name;
   }
}
