package org.example;


public class Message {
   public String messageBody;

   public Message (String messageBody) {
      this.messageBody = messageBody;
   }
}